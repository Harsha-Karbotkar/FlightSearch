-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 04, 2023 at 05:13 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flightbookings`
--

-- --------------------------------------------------------

--
-- Table structure for table `airline_master`
--

CREATE TABLE `airline_master` (
  `airline_id` int(11) NOT NULL,
  `airline_name` varchar(25) NOT NULL,
  `airline_code` varchar(10) NOT NULL,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `destination_master`
--

CREATE TABLE `destination_master` (
  `destination_id` int(11) NOT NULL,
  `destination` varchar(15) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `flight_master`
--

CREATE TABLE `flight_master` (
  `flight_id` int(11) NOT NULL,
  `airline_id` int(11) NOT NULL,
  `flight_number` varchar(10) NOT NULL,
  `operational_days` varchar(20) NOT NULL DEFAULT '7',
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `flight_trips`
--

CREATE TABLE `flight_trips` (
  `trip_id` int(11) NOT NULL,
  `flight_id` int(11) NOT NULL DEFAULT 0,
  `origin_id` int(11) DEFAULT NULL,
  `destination_id` int(11) DEFAULT NULL,
  `available_seats` smallint(3) NOT NULL DEFAULT 0,
  `price` float NOT NULL DEFAULT 0,
  `departure` datetime DEFAULT NULL,
  `arrival` datetime DEFAULT NULL,
  `duration` varchar(15) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `airline_master`
--
ALTER TABLE `airline_master`
  ADD PRIMARY KEY (`airline_id`);

--
-- Indexes for table `destination_master`
--
ALTER TABLE `destination_master`
  ADD PRIMARY KEY (`destination_id`);

--
-- Indexes for table `flight_master`
--
ALTER TABLE `flight_master`
  ADD PRIMARY KEY (`flight_id`),
  ADD KEY `airline_id` (`airline_id`);

--
-- Indexes for table `flight_trips`
--
ALTER TABLE `flight_trips`
  ADD PRIMARY KEY (`trip_id`),
  ADD KEY `flight_id` (`flight_id`),
  ADD KEY `origin_id` (`origin_id`),
  ADD KEY `destination_id` (`destination_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `airline_master`
--
ALTER TABLE `airline_master`
  MODIFY `airline_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `destination_master`
--
ALTER TABLE `destination_master`
  MODIFY `destination_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `flight_master`
--
ALTER TABLE `flight_master`
  MODIFY `flight_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `flight_trips`
--
ALTER TABLE `flight_trips`
  MODIFY `trip_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
