<?php

namespace App\Models;

use CodeIgniter\Model;

class FlightMasterModel extends Model
{
    public $table      = 'flight_master';
    public $primaryKey = 'flight_id';

    public $allowedFields = ['airline_id', 'flight_number','operational_days', 'created_date'];

    
}
