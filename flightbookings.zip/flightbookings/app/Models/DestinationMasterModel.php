<?php

namespace App\Models;

use CodeIgniter\Model;

class DestinationMasterModel extends Model
{
    public $table      = 'destination_master';
    public $primaryKey = 'destination_id';

    public $allowedFields = ['origin', 'destination','created_date'];

    
}
