<?php

namespace App\Models;

use CodeIgniter\Model;

class AirlineMasterModel extends Model
{
    public $table      = 'airline_master';
    public $primaryKey = 'airline_id';


    public $allowedFields = ['airline_name', 'airline_code', 'created_date'];

    
}
