<?php

namespace App\Models;

use CodeIgniter\Model;

class FlightTripsModel extends Model
{
    public $table      = 'flight_trips';
    public $primaryKey = 'trip_id';

    public $allowedFields = ['flight_id', 'origin_id','destination_id','available_seats', 'price', 'departure','arrival', 'duration','created_date','modified_date'];

    public function getResource($input_params=[])
    {

        $builder = $this->db->table('flight_trips');
        $builder->select('airline_master.airline_name,flight_master.flight_number,source.destination as source_name,destination.destination as destination_name');
        $builder->select('flight_trips.trip_id ,flight_trips.flight_id,flight_trips.origin_id,flight_trips.destination_id,flight_trips.available_seats,flight_trips.price,flight_trips.departure,DATE_FORMAT(flight_trips.departure, "%H:%i") as departure,DATE_FORMAT(flight_trips.arrival, "%H:%i") as arrival,flight_trips.duration');
        $builder->join('flight_master', 'flight_trips.flight_id = flight_master.flight_id');
        $builder->join('airline_master', 'flight_master.airline_id = airline_master.airline_id');
        $builder->join('destination_master as source', 'flight_trips.origin_id = source.destination_id ');
        $builder->join('destination_master as destination', 'flight_trips.destination_id = destination.destination_id');
        $builder->where('flight_trips.origin_id', $input_params['source'] );
        $builder->where('flight_trips.destination_id',  $input_params['destination']);
        $builder->where('flight_trips.available_seats >=',  $input_params['passenger']);
        
        $where_days = '(date(flight_trips.departure)="'.$input_params['departure_date'].'" or flight_master.operational_days like "%,'.$input_params['week_day'].',%")';
        $builder->where($where_days);

        $builder->orderBy('departure');

        $data = $builder->get()->getResultArray();

        //  $query = $this->db->getLastQuery();
        // $sql = $query->getQuery();
        // echo $sql; die;

        return $data;
    }


}
