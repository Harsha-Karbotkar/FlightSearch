<?php

namespace App\Controllers;

use CodeIgniter\RESTful\ResourcePresenter;
 use App\Models\AirlineMasterModel;
use App\Models\DestinationMasterModel;
use App\Models\FlightMasterModel;
use App\Models\FlightTripsModel;


class ApiController extends ResourcePresenter
{

    protected $airline =""; 
    protected $flight =""; 
    protected $destination =""; 
    protected $trips =""; 

    public function __construct()
    {
        $this->airline = new AirlineMasterModel();
        $this->flight = new FlightMasterModel();
        $this->destination = new DestinationMasterModel();
        $this->trips = new FlightTripsModel();

    }

    public function index()
	{
        $json_raw = file_get_contents('php://input');
        $json_raw = strip_tags(htmlspecialchars_decode($json_raw));    
        $json = json_decode($json_raw,true);


        $airline_data = [];
        $flight_data = [];
        $trip_data = [];
        $trip_temp = [];

        $error_data=[];

        try{
            foreach($json as $index=> $json_data){

                if(!empty($json_data['airlineCode']) && !empty($json_data['airline']) ){
    
                    $airline_data[$json_data['airlineCode']] = $json_data['airline'];
    
    
                    if(!empty($json_data['flightNumber'])){
    
                        if(!isset($flight_data[$json_data['airlineCode']]) || !in_array($json_data['flightNumber'],$flight_data[$json_data['airlineCode']])){
    
                            $flight_data[$json_data['airlineCode']][$json_data['flightNumber']] =$json_data['operationalDays'];
                        }
    
                        if(empty($json_data['departure']) || !strtotime($json_data['departure'])){
                            $error_data[] = 'Required Departure Date at index '.$index;
                        }

                        if(empty($json_data['arrival']) || !strtotime($json_data['arrival'])){
                            $error_data[] = 'Required Arrival Date at index '.$index;
                        }
    
                        if(!empty($json_data['origin']) && !empty($json_data['destination'])){
    
                            if(isset($json_data['availableSeats']) && $json_data['availableSeats']>0){
    
                               
                                $trip_temp['available_seats'] = $json_data['availableSeats'];
                                $trip_temp['departure'] = $json_data['departure'];
                                $trip_temp['arrival'] = $json_data['arrival'];
                                $trip_temp['price'] = $json_data['price'];
                                $trip_temp['duration'] = $json_data['duration'];
                                $trip_temp['origin'] = $json_data['origin'];
                                $trip_temp['destination'] = $json_data['destination'];
                
                                $trip_data[$json_data['flightNumber']][] =  $trip_temp;
    
                            }
                            else{
                                $error_data[] = 'Required data for origin/destination at index '.$index;
                            }
            
                        }
                        else{
                            $error_data[] = 'Required data for origin/destination at index '.$index;
                        }
        
                    }
                    else{
                        $error_data[] = 'Required data for flightNumber at index '.$index;
                    }
    
                }
                else{
                    $error_data[] = 'Required data for airlineCode/airline at index '.$index;
                }
    
            }
            
        }catch (\Exception $e) {
            $reponse['message'] = 'Invalid Format';
            $reponse['status'] = 200;
            echo json_encode($reponse);
            exit;
        }

        if(count($error_data)>0){
            $reponse['message'] = $error_data;
            $reponse['status'] = 200;
            echo json_encode($reponse);
            exit;
        }

        $airlineData = $this->airline->find();
        $airline_master = array_column($airlineData, "airline_code");


        $flightData = $this->flight->find();
        $flight_master = array_column($flightData, "flight_number");


        $destinationData = $this->destination->find();
        $destination_master = array_column($destinationData, "destination");


        $destination_temp_data =[];
        foreach($airline_data as $airlineCode=>$airline_name){

            if(!in_array($airlineCode,$airline_master)){
                $airline_insert = [
                    'airline_name' => $airline_name,
                    'airline_code' => $airlineCode,
                    'created_date' => date('Y-m-d H:i:s')
                ];
                 $this->airline->insert($airline_insert);
                 $airline_id = $this->airline->getInsertID();

            }
            else{
                $air_key = array_search($airlineCode, $airline_master);
                $airline_id = $airlineData[$air_key]['airline_id'];
            }


            foreach($flight_data[$airlineCode] as $flightNumber=>$operational_days){


                if(!in_array($flightNumber,$flight_master)){

                    $operational_days_str = ",".implode(',',$operational_days).",";
                    $flight_insert = [
                        'airline_id' => $airline_id,
                        'flight_number' => $flightNumber,
                        'operational_days' => $operational_days_str,
                        'created_date' => date('Y-m-d H:i:s')
                    ];
                     $this->flight->insert($flight_insert);
                     $flight_id = $this->flight->getInsertID();
                }
                else{
                    $flight_key = array_search($flightNumber, $flight_master);
                    $flight_id = $flightData[$flight_key]['flight_id'];
                }

                foreach($trip_data[$flightNumber] as $trip_details){

                    $origin  = $trip_details['origin'];
                    $destination  = $trip_details['destination'];
                    $departure   = date('Y-m-d H:i:s',strtotime($trip_details['departure']));
                    $arrival   = date('Y-m-d H:i:s',strtotime($trip_details['arrival']));


                    if(!in_array($origin,$destination_master) && !isset($destination_temp_data[$origin])){

                        array_push( $destination_temp_data,$origin);
                        $destination_insert = [
                            'destination' => $origin,
                            'created_date' => date('Y-m-d H:i:s')
                        ];
                        $this->destination->insert($destination_insert);
                        $origin_id = $this->destination->getInsertID();
                        $destination_temp_data[$origin] = $origin_id;
                    }
                    else if(isset($destination_temp_data[$origin])){
                        $origin_id = $destination_temp_data[$origin];
                    }
                    else{

                        $destination_key = array_search($origin, $destination_master);
                        $origin_id = $destinationData[$destination_key]['destination_id'];

                    }

                   
                    if(!in_array($destination,$destination_master) && !isset($destination_temp_data[$destination])){
                        array_push( $destination_temp_data,$destination);
                        $destination_insert = [
                            'destination' => $destination,
                            'created_date' => date('Y-m-d H:i:s')
                        ];
                        $this->destination->insert($destination_insert);
                        $destination_id = $this->destination->getInsertID();
                        $destination_temp_data[$destination] = $destination_id;
                    }
                    else if(isset($destination_temp_data[$destination])){
                        $destination_id = $destination_temp_data[$destination];
                    }
                    else{
                        $destination_key = array_search($destination, $destination_master);
                        $destination_id = $destinationData[$destination_key]['destination_id'];
                    }

                    $tripData = $this->trips
                    ->where('flight_id', $flight_id)
                    ->where('origin_id', $origin_id )
                    ->where('destination_id',  $destination_id)
                    ->where('departure',  $departure)
                    ->find();
                   
                    if($tripData){

                        $trip_update = [
                            'arrival' =>$arrival,
                            'price' =>$trip_details['price'],
                            'duration' =>$trip_details['duration'],
                            'available_seats' =>$trip_details['available_seats'],
                            'modified_date' =>date('Y-m-d H:i:s')
                        ];

                         $this->trips->where('trip_id',$tripData[0]['trip_id'])->set($trip_update)->update();
                       
                    }
                    else{
                        $trip_insert = [
                            'flight_id' =>$flight_id,
                            'origin_id'  =>$origin_id,
                            'destination_id' =>$destination_id,
                            'departure' =>$departure,
                            'arrival' =>$arrival,
                            'price' =>$trip_details['price'],
                            'duration' =>$trip_details['duration'],
                            'available_seats' =>$trip_details['available_seats'],
                            'created_date' => date('Y-m-d H:i:s')
                        ];
                       
                        $this->trips->insert($trip_insert);
                       
                    }
                }
            }
            
        }

        $reponse['message'] = 'Json uploaded Successfully';
        $reponse['status'] = 200;

        return json_encode($reponse);

    }


}

?>