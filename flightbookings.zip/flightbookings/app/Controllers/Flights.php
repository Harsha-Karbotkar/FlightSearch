<?php

namespace App\Controllers;

use App\Models\DestinationMasterModel;
use App\Models\FlightTripsModel;

class Flights extends BaseController
{
    protected $airline =""; 
    protected $flight =""; 
    protected $destination =""; 
    protected $trips =""; 

    public function __construct()
    {
        $this->destination = new DestinationMasterModel();
        $this->trips = new FlightTripsModel();
    }

    public function index()
    {

        $destinationData = $this->destination->select('destination_id,destination')->find();

        $data = [
            'destinations'  =>  $destinationData,
            'msg'=>'Praseel'
        ];

        return view('flight_search', $data);
    }

    public function getFlights()
    {

        $errors = [];
        $data = [];
       
        if (empty($_POST['departure_date'])) {
            $errors['departure_date'] = 'Departure Date is required.';
        }

        if (empty($_POST['source'])) {
            $errors['source'] = 'Source is required.';
        }

        if (empty($_POST['destination'])) {
            $errors['destination'] = 'Destination is required.';
        }

        if (empty($_POST['passenger'])) {
            $errors['passenger'] = 'Passenger is required.';
        }

        if (!empty($_POST['passenger']) && $_POST['passenger']==0) {
            $errors['passenger'] = 'Passengers Cannot be 0';
        }

        if ($_POST['is_return']=='true' && empty($_POST['return_date'])) {
            $errors['return_date'] = 'Return Date is required.';
        }

        $input_params =[
            'departure_date' => $_POST['departure_date'],
            'source' => $_POST['source'],
            'destination' => $_POST['destination'],
            'passenger' => $_POST['passenger'],
            'is_return' => $_POST['is_return'],
            'week_day' => date('w', strtotime($_POST['departure_date']))
        ];

        $tripsData=[];
        $tripsData_return=[];

        $tripsData = $this->trips->getResource($input_params);
       

        if($_POST['is_return']=='true'){
            $input_params =[
                'departure_date' => $_POST['return_date'],
                'source' => $_POST['destination'],
                'destination' => $_POST['source'],
                'passenger' => $_POST['passenger'],
                'is_return' => $_POST['is_return'],
                'week_day' => date('w', strtotime($_POST['return_date']))
            ];
            $tripsData_return = $this->trips->getResource($input_params);
       
        }

        if (!empty($errors)) {
            $data['success'] = false;
            $data['errors'] = $errors;
        } else {
            $data['success'] = true;
            $data['message'] = 'Success!';
            $data['data']['tripsData'] = $tripsData;
            $data['data']['tripsDataReturn'] = $tripsData_return;
        }


        echo json_encode($data);
    }


}
