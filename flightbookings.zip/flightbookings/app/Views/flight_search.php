<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Flight Search</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/flights.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
      
    <script src="/js/bootstrap.bundle.min.js"></script>
    <script src="/js/popper.min.js"></script>
    <script src="/js/bootstrap.min.js"></script>
    <script src= "/js/jquery.min.js"> </script> 
    <script src= "/js/jquery-ui.min.js"></script> 
    <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css">


</head>

<body>

    <div class="container">
        <div class="card card-default ">
            <div class="card-body">
                <div id="cover-spin"></div>
                <div class="card-header" id="filter-div" style="margin-bottom: 2%;">
                        <form action="/flight_search" method="post" id="form-filter">
                            <div class="form-row align-items-center search-row">
                            
                                <div class="col-sm-3 form-group" id="departure-date-group">
                                    <label class="col-form-label col-form-label-sm">Departure Date</label>
                                    <input type="text" name="departure_date" id="departure_date" class="form-control form-control-sm" autocomplete="off">
                                </div>
                            
                                <div class="col-sm-3 form-group" id="source-group">
                                    <label class="col-form-label col-form-label-sm">Source</label>
                                    <select id="source" class="form-control form-control-sm" name="source">
                                        <option value="">Select Source</option>
                                    </select>
                                </div>
                            
                                <div class="col-sm-3 form-group" id="destination-group">
                                    <label class="col-form-label col-form-label-sm">Destination</label>
                                    <select id="destination" class="form-control form-control-sm" name="destination">
                                        <option value="">Select Destination</option>
                                    </select>
                                </div>


                                <div class="col-sm-3 form-group" id="passenger-group">
                                    <label class="col-form-label col-form-label-sm">Passenger</label>
                                    <input type="number" name="passenger" class="form-control form-control-sm numberonly" id="passenger" min="1" max="150" value="1">
                                </div>


                                <div class="col-sm-2 form-group">
                                    Add Return+
                                    <input type="checkbox" id="is_return" name="is_return" value="is_return">
                                </div>


                                <div class="col-sm-3 form-group return_date_visibility" id="return_date-group">
                                    <label class="col-form-label col-form-label-sm">Return Date</label>
                                    <input type="text" name="return_date" id="return_date" class="form-control form-control-sm " autocomplete="off">
                                </div>


                                <button id="Search" type="submit" class="btn-sm btn-primary" style="float: right;margin-bottom:1%;">Search</button>
                            </div>
                            
                        </form>
                </div>
            </div>
        </div>

        <div class="card card-default listing_grid">
            <div class="card-header">
              <h6 class="m-b-20 text-left airline_text">Total Price: <i class="fa fa-rupee"></i><label class="show_price">0</label></h6>
             
            </div>
            <div class="card-body">

                <div class="row">
                
                    <div class="col-sm-6  card-grid one-way">
                    </div>

                    <div class="col-sm-6  card-grid two-way">
                    </div>
                </div>
            </div>
            
        </div>
    </div>



   
</body>
</html>

<script type="text/javascript">

    var destination_json = <?php echo json_encode($destinations); ?>; 
    var preValue_source ="";

    $(document).ready(function() {

        $("#departure_date").datepicker({
            dateFormat: 'yy-mm-dd',
            minDate: new Date(),
            maxDate: '+1Y',
            onSelect: function(date){
                var selectedDate = new Date(date);
                var endDate = new Date(selectedDate.getTime());
                $("#return_date").datepicker( "option", "minDate", endDate );
            }
        });
        $("#return_date").datepicker({
            dateFormat: 'yy-mm-dd',
            minDate: new Date(),
            maxDate: '+1Y'
        });

        

        var destination_options = "";
        $(destination_json).each(function( index,item ) {
            destination_options+= "<option value="+item['destination_id']+">"+item['destination']+"</option>";
        });
        $('#source').append(destination_options);
        $('#destination').append(destination_options);


        $('.numberonly').keypress(function (e) {    
        
            var charCode = (e.which) ? e.which : event.keyCode    
            if (String.fromCharCode(charCode).match(/[^0-9]/g))    
                return false;                        
            });  

    });

    $(document).ready(function(){
        $('input[type=radio]').change(function(){
            alert($(this).val());
            
        });
    });
    


    $('input[name="is_return"]').change(function () {
        if (this.checked) {
            $(".return_date_visibility").show();
        }
        else{
            $(".return_date_visibility").hide();
            $('#return_date').datepicker('setDate', null);
        }
    });


    $("#source").change(function () {
        var prev_source = preValue_source;
        $("#destination option[value*='"+prev_source+"']").prop('disabled',false);

        var source = this.value;
        $("#destination option[value*='"+source+"']").prop('disabled',true);
    });


    $("#source").click(
        function(){
            preValue_source =$("#source").val();
        }
    );

    $("form").submit(function (event){

        event.preventDefault();
        $("div").remove(".one-way-cards");
        $("div").remove(".two-way-cards");
        $('.show_price').text(0);
        $(".form-group").removeClass("has-error");
        $(".help-block").remove();

        var is_return  = $('#is_return').is(":checked");

        var formData = {
            departure_date: $("#departure_date").val(),
            source: $("#source").val(),
            destination: $("#destination").val(),
            passenger: $("#passenger").val(),
            is_return: is_return.toString(),
            return_date: $("#return_date").val(),
        };


        $.ajax({
            type: "POST",
            url: "/flight_search",
            type: "POST",
            data: formData,
            dataType: "json",
            encode: true
        }).done(function (data) {
            if (!data.success) {
                
                if (data.errors.departure_date) {
                    $("#departure-date-group").addClass("has-error");
                    $("#departure-date-group").append(
                        '<div class="help-block">' + data.errors.departure_date + "</div>"
                    );
                }

                if (data.errors.source) {
                    $("#source-group").addClass("has-error");
                    $("#source-group").append(
                        '<div class="help-block">' + data.errors.source + "</div>"
                    );
                }

                if (data.errors.destination) {
                    $("#destination-group").addClass("has-error");
                    $("#destination-group").append(
                        '<div class="help-block">' + data.errors.destination + "</div>"
                    );
                }

                if (data.errors.passenger) {
                    $("#passenger-group").addClass("has-error");
                    $("#passenger-group").append(
                        '<div class="help-block">' + data.errors.passenger + "</div>"
                    );
                }

                if (data.errors.return_date) {
                    $("#return_date-group").addClass("has-error");
                    $("#return_date-group").append(
                        '<div class="help-block">' + data.errors.return_date + "</div>"
                    );
                }

            }
            else{
 
                $('.listing_grid').show();
                var response= data.data
                var one_way_cards = " <div class='col-sm-12 col-form-label col-form-label-sm card-label  one-way-cards'>One Way Flights</div>";
               var return_way_cards = "<div class='col-sm-12 col-form-label col-form-label-sm card-label  two-way-cards'>Return Flights</div>";

               if(response['tripsData'].length>0){
                    $(response['tripsData']).each(function( index,item ) {
                        one_way_cards+= '<div class="card listing-cards one-way-cards">';
                        one_way_cards+= '<div class="card-header"><h6 class="m-b-20 text-left airline_text">';
                        one_way_cards+= '<label><input type="radio"  value ="'+item['price']+'" name="one_way_check" id="one_way_check_'+item['trip_id']+'" onchange="priceChange();"></label>';
                        one_way_cards+= item['airline_name']+'-'+item['flight_number']+'<i class="fa fa-plane" aria-hidden="true"></i></h6></div>';;
                        one_way_cards+= '<div class="card-block"><div class="row card-details">';
                        one_way_cards+= ' <p class="col-sm-3 card-text departure_text">'+item['departure']+'</p>';
                        one_way_cards+= '<p class="col-sm-3 card-text line duration_text">'+item['duration']+'</p>';
                        one_way_cards+= '<p class=" col-sm-3 card-text arrival_text">'+item['arrival']+'</p>';
                        one_way_cards+= '<p class="col-sm-3 card-text price_text"><i class="fa fa-rupee"></i>'+item['price']+'</p></div>';
                        one_way_cards+= '<div class="row card-details">';
                        one_way_cards+= '<p class="col-sm-3 card-text source_text">'+item['source_name']+'</p>';
                        one_way_cards+= '<p class="col-sm-3 card-text "></p>';
                        one_way_cards+= '<p class=" col-sm-3 card-text destination_text">'+item['destination_name']+'</p>';
                        one_way_cards+= '<p class="col-sm-3 card-text">per adult</p></div></div></div>';

                    });

               }
               else{
                    one_way_cards+= '<div class="card listing-cards one-way-cards">';
                    one_way_cards+= '<h6 class="m-b-20 text-left airline_text"></i>Flights not Available</h6></div>';
               }

                $('.one-way').append(one_way_cards);

                if(is_return==true){
                    if(response['tripsDataReturn'].length>0){
                        $(response['tripsDataReturn']).each(function( index,item ) {
                            return_way_cards+= '<div class="card listing-cards two-way-cards">';
                            return_way_cards+= ' <div class="card-header"><h6 class="m-b-20 text-left airline_text">';
                            return_way_cards+= '<label><input type="radio"  value ="'+item['price']+'" name="two_way_check"  id="two_way_check_'+item['trip_id']+'" onchange="priceChange();"></label>';
                            return_way_cards+= item['airline_name']+'-'+item['flight_number']+'<i class="fa fa-plane" aria-hidden="true"></i></h6></div>';
                            return_way_cards+= '<div class="card-block"><div class="row card-details">';
                            return_way_cards+= ' <p class="col-sm-3 card-text departure_text">'+item['departure']+'</p>';
                            return_way_cards+= '<p class="col-sm-3 card-text line duration_text">'+item['duration']+'</p>';
                            return_way_cards+= '<p class=" col-sm-3 card-text arrival_text">'+item['arrival']+'</p>';
                            return_way_cards+= '<p class="col-sm-3 card-text price_text"><i class="fa fa-rupee"></i>'+item['price']+'</p></div>';
                            return_way_cards+= '<div class="row card-details">';
                            return_way_cards+= '<p class="col-sm-3 card-text source_text">'+item['source_name']+'</p>';
                            return_way_cards+= '<p class="col-sm-3 card-text "></p>';
                            return_way_cards+= '<p class=" col-sm-3 card-text destination_text">'+item['destination_name']+'</p>';
                            return_way_cards+= '<p class="col-sm-3 card-text">per adult</p></div></div></div>';

                        });
                    }
                    else{
                        return_way_cards+= '<div class="card listing-cards two-way-cards">';
                        return_way_cards+= '<h6 class="m-b-20 text-left airline_text"></i>Flights not Available</h6></div>';
                    }
                
                    $('.two-way').append(return_way_cards);
                    
                }


            }
        });
        event.preventDefault();
    });


    function priceChange(){
        var one_way_val = 0;
        var one_way_price =   $("input[type='radio'][name='one_way_check']:checked");
        if (one_way_price.length > 0) {
            one_way_val = one_way_price.val();
        }

        var two_way_val = 0;
        var two_way_price =   $("input[type='radio'][name='two_way_check']:checked");
        if (two_way_price.length > 0) {
            two_way_val = two_way_price.val();
        }

        var total_price =   parseInt(one_way_val)+ parseInt(two_way_val);
        $('.show_price').text(new Intl.NumberFormat('en-IN').format(total_price));

    }

 

</script>