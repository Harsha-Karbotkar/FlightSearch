<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Flights::index');
$routes->post("pushflightdata", "ApiController::index");
$routes->post("flight_search", "Flights::getFlights");
